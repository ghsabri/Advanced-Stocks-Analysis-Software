# TR INDICATOR CHART PLOTTER - USER GUIDE

## 📊 Overview

The TR Chart Plotter creates professional stock charts with visual TR indicator stages, following your exact specifications.

---

## 🎨 VISUAL SPECIFICATIONS

### **Stage 1 Signals (Markers Only)**
- **Uptrend Stage 1 (Neutral Buy)**: Light green triangle (▲) pointing upward
- **Downtrend Stage 1 (Neutral Sell)**: Red diamond (◆)
- **Behavior**: Marker appears ONLY at the FIRST price point when entering Stage 1
- **Background**: White (plain, no bands)

### **Stage 2 & 3 Signals (Background Bands)**
- **Uptrend Stage 2 (Buy)**: Light green vertical band
- **Uptrend Stage 3 (Strong Buy)**: Dark green vertical band
- **Downtrend Stage 2 (Sell)**: Light yellow vertical band
- **Downtrend Stage 3 (Strong Sell)**: Orange vertical band
- **Behavior**: Vertical bands run from top to bottom of chart
- **Duration**: Bands disappear when trend changes back to Stage 1

---

## 🚀 QUICK START

### **Method 1: Simplest - One-Line Chart**

```python
from tr_chart_plotter import quick_tr_chart

# Generate basic chart
quick_tr_chart('AAPL', timeframe='daily', duration_days=180, chart_type='basic')

# Generate enhanced chart (with buy zones, signals)
quick_tr_chart('MSFT', timeframe='weekly', duration_days=730, chart_type='enhanced')
```

### **Method 2: With Custom Data**

```python
from tr_enhanced import analyze_stock_complete_tr
from tr_chart_plotter import plot_tr_indicator_chart

# Get TR data
df = analyze_stock_complete_tr('TSLA', timeframe='daily', duration_days=180)

# Create chart
fig = plot_tr_indicator_chart(df, ticker='TSLA', timeframe='Daily')
plt.show()
```

### **Method 3: Enhanced Chart with All Features**

```python
from tr_enhanced import analyze_stock_complete_tr
from tr_chart_plotter import plot_tr_with_buy_zones

# Get complete TR data
df = analyze_stock_complete_tr('NVDA', timeframe='daily', duration_days=180)

# Create enhanced chart with buy zones, signals, stop losses
fig = plot_tr_with_buy_zones(
    df=df,
    ticker='NVDA',
    timeframe='Daily',
    save_path='charts/NVDA_TR_Chart.png'
)
plt.show()
```

---

## 📁 FILE STRUCTURE

```
your_project/
├── src/
│   ├── tr_calculations.py       # Technical indicators
│   ├── tr_indicator.py          # TR signal logic
│   ├── tr_enhanced.py           # Complete TR analysis
│   └── tr_chart_plotter.py      # NEW: Chart visualization
├── charts/                      # NEW: Generated charts saved here
└── test_tr_charts.py            # NEW: Test script
```

---

## 🎯 FUNCTION REFERENCE

### **1. plot_tr_indicator_chart()**

Creates basic TR chart with bands and stage markers.

```python
plot_tr_indicator_chart(
    df,                          # DataFrame with TR data
    ticker,                      # Stock symbol (e.g., 'AAPL')
    timeframe='Daily',           # 'Daily', 'Weekly', or 'Monthly'
    save_path=None,              # Path to save (e.g., 'charts/AAPL.png')
    figsize=(16, 10)             # Chart size (width, height)
)
```

**Returns**: matplotlib Figure object

**Features**:
- ✅ Price line (black)
- ✅ Stage 1 markers (triangles & diamonds)
- ✅ Stage 2 & 3 background bands
- ✅ Legend explaining all elements
- ✅ Date formatting and grid

---

### **2. plot_tr_with_buy_zones()**

Creates enhanced chart with buy zones, signals, and stop losses.

```python
plot_tr_with_buy_zones(
    df,                          # Complete TR DataFrame
    ticker,                      # Stock symbol
    timeframe='Daily',           # Timeframe
    save_path=None,              # Save path
    figsize=(16, 12)             # Larger chart size
)
```

**Returns**: matplotlib Figure object

**Features**:
- ✅ Everything from basic chart, PLUS:
- ✅ Buy zones (±5% shaded blue regions)
- ✅ Buy points (dashed blue horizontal lines)
- ✅ Stop losses (dashed red horizontal lines at -8%)
- ✅ Buy signals (green stars ⭐)
- ✅ Exit signals (red X markers)

---

### **3. quick_tr_chart()**

One-line function to generate charts directly from ticker symbol.

```python
quick_tr_chart(
    ticker,                      # Stock symbol (e.g., 'AAPL')
    timeframe='daily',           # 'daily', 'weekly', or 'monthly'
    duration_days=180,           # Days of historical data
    chart_type='basic'           # 'basic' or 'enhanced'
)
```

**Returns**: matplotlib Figure object

**What it does**:
1. Fetches stock data
2. Calculates TR indicators
3. Generates chart
4. Saves to `charts/` directory
5. Displays chart

---

## 💡 USAGE EXAMPLES

### **Example 1: Quick Daily Chart**

```python
from tr_chart_plotter import quick_tr_chart

# Generate and display AAPL daily chart (last 6 months)
quick_tr_chart('AAPL', timeframe='daily', duration_days=180, chart_type='basic')
```

### **Example 2: Weekly Analysis with Buy Zones**

```python
# Generate TSLA weekly chart (last 2 years) with buy zones
quick_tr_chart('TSLA', timeframe='weekly', duration_days=730, chart_type='enhanced')
```

### **Example 3: Multiple Stocks Comparison**

```python
from tr_chart_plotter import quick_tr_chart

stocks = ['AAPL', 'MSFT', 'GOOGL', 'NVDA', 'META']

for stock in stocks:
    print(f"Generating chart for {stock}...")
    quick_tr_chart(stock, timeframe='daily', duration_days=90, chart_type='basic')
```

### **Example 4: Custom Chart with Specific Settings**

```python
from tr_enhanced import analyze_stock_complete_tr
from tr_chart_plotter import plot_tr_with_buy_zones
import matplotlib.pyplot as plt

# Fetch data
df = analyze_stock_complete_tr('NVDA', timeframe='daily', duration_days=365)

# Create custom-sized chart
fig = plot_tr_with_buy_zones(
    df=df,
    ticker='NVDA',
    timeframe='Daily',
    save_path='charts/NVDA_1Year_TR.png',
    figsize=(20, 14)  # Extra large for detailed analysis
)

# Display
plt.show()
```

### **Example 5: Batch Processing**

```python
from tr_chart_plotter import quick_tr_chart

# Your watchlist
watchlist = ['HOOD', 'UBER', 'COIN', 'SQ', 'RBLX']

print("Generating charts for entire watchlist...")

for ticker in watchlist:
    try:
        quick_tr_chart(
            ticker=ticker,
            timeframe='weekly',
            duration_days=365,
            chart_type='enhanced'
        )
        print(f"✅ {ticker} complete")
    except Exception as e:
        print(f"❌ {ticker} failed: {e}")

print("All charts generated!")
```

---

## 🧪 TESTING

Run the comprehensive test suite:

```bash
python test_tr_charts.py
```

This will:
1. ✅ Create `charts/` directory
2. ✅ Generate basic TR chart (AAPL)
3. ✅ Generate enhanced chart with buy zones (MSFT)
4. ✅ Generate weekly chart (TSLA)
5. ✅ Generate multiple stock charts (NVDA, META, GOOGL)
6. ✅ Create custom chart from existing data
7. ✅ Save all charts to `charts/` directory

---

## 📊 CHART ELEMENTS EXPLAINED

### **Price Line**
- **Color**: Black
- **Width**: 1.5 pixels
- **Represents**: Daily/Weekly closing prices

### **Stage 1 Uptrend Marker (▲)**
- **Color**: Light green with dark green outline
- **Shape**: Triangle pointing upward
- **Size**: 100 points
- **Appears**: At FIRST price point of Stage 1 uptrend only

### **Stage 1 Downtrend Marker (◆)**
- **Color**: Red with dark red outline
- **Shape**: Diamond
- **Size**: 80 points
- **Appears**: At FIRST price point of Stage 1 downtrend only

### **Stage 2 Uptrend Band (Buy)**
- **Color**: Light green (#90EE90)
- **Opacity**: 30%
- **Vertical**: Runs from bottom to top of chart
- **Duration**: While in Stage 2 uptrend

### **Stage 3 Uptrend Band (Strong Buy)**
- **Color**: Dark green (#006400)
- **Opacity**: 30%
- **Vertical**: Runs from bottom to top of chart
- **Duration**: While in Stage 3 uptrend

### **Stage 2 Downtrend Band (Sell)**
- **Color**: Light yellow (#FFFFE0)
- **Opacity**: 30%
- **Vertical**: Runs from bottom to top of chart
- **Duration**: While in Stage 2 downtrend

### **Stage 3 Downtrend Band (Strong Sell)**
- **Color**: Orange (#FFA500)
- **Opacity**: 30%
- **Vertical**: Runs from bottom to top of chart
- **Duration**: While in Stage 3 downtrend

### **Buy Zone (Enhanced Chart Only)**
- **Color**: Blue
- **Opacity**: 10%
- **Shape**: Horizontal shaded region
- **Range**: ±5% of buy point

### **Buy Point Line (Enhanced Chart Only)**
- **Color**: Blue
- **Style**: Dashed
- **Width**: 1.5 pixels
- **Position**: At peak (pivot high) price

### **Stop Loss Line (Enhanced Chart Only)**
- **Color**: Red
- **Style**: Dashed
- **Width**: 1.5 pixels
- **Position**: 8% below buy point

### **Buy Signal (Enhanced Chart Only)**
- **Symbol**: Green star (⭐)
- **Size**: 300 points
- **Appears**: When entering Stage 2/3 while in buy zone

### **Exit Signal (Enhanced Chart Only)**
- **Symbol**: Red X
- **Size**: 200 points
- **Appears**: When hitting stop loss or entering sell stage

---

## ⚙️ CUSTOMIZATION OPTIONS

### **Adjust Chart Size**

```python
# Larger chart for detailed analysis
fig = plot_tr_indicator_chart(df, ticker='AAPL', figsize=(24, 14))

# Smaller chart for quick view
fig = plot_tr_indicator_chart(df, ticker='AAPL', figsize=(12, 8))
```

### **Save High-Resolution Image**

```python
fig = plot_tr_indicator_chart(df, ticker='AAPL')
plt.savefig('AAPL_Chart.png', dpi=600, bbox_inches='tight')  # Publication quality
```

### **Change Date Range**

```python
# Last 30 days only
df = analyze_stock_complete_tr('AAPL', duration_days=30)

# Last 5 years
df = analyze_stock_complete_tr('AAPL', duration_days=1825)
```

---

## 🐛 TROUBLESHOOTING

### **Issue: Chart not displaying**
```python
# Add this at the end
import matplotlib.pyplot as plt
plt.show()
```

### **Issue: Charts directory doesn't exist**
```python
import os
os.makedirs('charts', exist_ok=True)
```

### **Issue: Import errors**
```python
# Make sure all TR modules are in the same directory or in your Python path
import sys
sys.path.append('path/to/your/src/directory')
```

### **Issue: Data fetching fails**
```python
# Check if you have internet connection
# Verify Tiingo API is accessible
# Try with a different ticker symbol
```

---

## 📚 INTEGRATION WITH EXISTING CODE

### **With weekly_scanner.py**

```python
from tr_enhanced import analyze_stock_complete_tr
from tr_chart_plotter import plot_tr_with_buy_zones

tickers = ['HOOD', 'UBER', 'GOOGL', 'AMZN', 'NVDA', 'TSLA', 'META']

for ticker in tickers:
    df = analyze_stock_complete_tr(ticker, timeframe='weekly', duration_days=730)
    
    if df is not None:
        # Generate chart
        plot_tr_with_buy_zones(
            df, 
            ticker, 
            timeframe='Weekly',
            save_path=f'charts/{ticker}_Weekly_TR.png'
        )
```

### **With tr_daily_screener.py**

```python
from tr_enhanced import analyze_stock_complete_tr
from tr_chart_plotter import quick_tr_chart

stocks = ['UBER', 'HOOD', 'GOOGL', 'AMZN', 'NVDA', 'TSLA', 'META']

for stock in stocks:
    df = analyze_stock_complete_tr(stock)
    
    if '* ' in df.iloc[-1]['TR_Status_Enhanced']:
        print(f"{stock}: Market Leader - Generating chart...")
        quick_tr_chart(stock, chart_type='enhanced')
```

---

## ✅ SUMMARY

**You now have:**
1. ✅ Complete TR indicator charting system
2. ✅ Two chart types: Basic and Enhanced
3. ✅ Stage visualization exactly as specified
4. ✅ Buy zones, signals, and stop losses
5. ✅ Easy-to-use functions
6. ✅ Batch processing capabilities
7. ✅ High-quality output for analysis

**Ready to use for Phase II and beyond!** 🚀

---

## 📞 NEXT STEPS

Now that charting is complete, you're ready for:
- ✅ **Week 2**: Pattern Detection & Additional Indicators
- ✅ **Week 3**: Advanced Analytics & Signal Generation
- ✅ **Week 4**: User Interface Development

**Your TR Indicator visualization is production-ready!** 🎉
