# 🚀 Watchlists Integration Guide

## Quick Setup (5 Minutes)

### Step 1: Copy Files

Copy the watchlists page to your project:

```bash
# Copy from outputs to your project
cp 3_Watchlists.py "C:\Work\Stock Analysis Project\mj-stocks-analysis\pages\"
```

### Step 2: Test Locally

```bash
# Navigate to your project directory
cd "C:\Work\Stock Analysis Project\mj-stocks-analysis"

# Run Streamlit
streamlit run app.py
```

### Step 3: Verify

1. Open browser to `http://localhost:8501`
2. Navigate to "Watchlists" page
3. Create a test watchlist
4. Add a stock (e.g., AAPL)
5. Click "Analyze All Stocks"

---

## 📋 Pre-Deployment Checklist

### Required Files in Your Project

```
mj-stocks-analysis/
├── pages/
│   ├── 3_Watchlists.py  ← NEW (copy this)
│   ├── 1_Stocks_Analysis.py  ← Existing
│   └── 6_Indicator_Chart.py  ← Existing
├── src/
│   ├── cached_data.py  ← Must exist
│   ├── stock_lookup.py  ← Must exist
│   └── (other modules)
```

### Dependencies Check

Verify these packages are in your `requirements.txt`:

```text
streamlit>=1.28.0
pandas>=2.0.0
plotly>=5.17.0
yfinance>=0.2.28
```

---

## 🔄 Migration to Database (Week 2)

### When to Migrate

Migrate to Supabase when:
- ✅ Beta testing starts (Week 10)
- ✅ Multiple users need persistent storage
- ✅ Data needs to survive browser restarts

### Migration Steps

#### 1. Set Up Supabase

```bash
# Create account at supabase.com
# Create new project
# Note your Project URL and API Key
```

#### 2. Run Database Schema

In Supabase SQL Editor, run:

```sql
-- Copy entire SQL schema from watchlist_database.py
-- (Lines 180-310)
```

#### 3. Update Environment Variables

```bash
# Add to .env file
SUPABASE_URL=your-project-url-here
SUPABASE_KEY=your-anon-key-here
```

#### 4. Install Supabase Client

```bash
pip install supabase
```

#### 5. Update Code

Replace session state functions with database functions:

```python
# In 3_Watchlists.py, add at top:
from watchlist_database import (
    create_watchlist_db,
    get_user_watchlists_db,
    add_stock_to_watchlist_db,
    # ... other functions
)

# Replace session state calls:
# Before:
create_watchlist(name)

# After:
create_watchlist_db(user_id, name)
```

---

## 🎨 Customization Options

### Change Colors

In `3_Watchlists.py`, modify the CSS:

```css
/* Strong Buy color */
.tr-strong-buy {
    background-color: #00CC00;  /* Change this */
}
```

### Change Cache Duration

```python
# Line ~230 in 3_Watchlists.py
# Current: 5 minutes (300 seconds)
if (datetime.now() - cached_time).seconds < 300:

# Change to 10 minutes:
if (datetime.now() - cached_time).seconds < 600:
```

### Add Stock Limit Per Watchlist

```python
# In add_stock_to_watchlist function
def add_stock_to_watchlist(watchlist_id, symbol):
    if watchlist_id in st.session_state.watchlists:
        stocks = st.session_state.watchlists[watchlist_id]['stocks']
        
        # Add limit check
        if len(stocks) >= 50:  # Max 50 stocks
            st.error("⚠️ Watchlist limit reached (50 stocks)")
            return False
            
        if symbol not in stocks:
            stocks.append(symbol)
            return True
    return False
```

---

## 🐛 Troubleshooting

### Issue: "Module not found: cached_data"

**Solution:** Verify `src/` directory is in Python path

```python
# This should be at top of 3_Watchlists.py
import sys
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
src_path = os.path.join(project_root, 'src')

if src_path not in sys.path:
    sys.path.insert(0, src_path)
```

### Issue: "get_stock_info not found"

**Solution:** Ensure `stock_lookup.py` exists in `src/` with function:

```python
def get_stock_info(symbol):
    """Return stock info dict or None"""
    pass
```

### Issue: Slow Analysis

**Solutions:**
1. Reduce number of stocks in watchlist
2. Increase cache duration
3. Use `include_tr=False` for faster analysis (no TR status)

### Issue: Cache Not Working

**Solution:** Check session state is initialized:

```python
if 'stock_tr_cache' not in st.session_state:
    st.session_state.stock_tr_cache = {}
```

---

## 📊 Testing Scenarios

### Test Case 1: Basic Functionality

```
1. Create watchlist "Test Portfolio"
2. Add AAPL, MSFT, GOOGL
3. Click "Analyze All Stocks"
4. Verify TR status displays
5. Remove MSFT
6. Verify it's gone
7. Delete watchlist
8. Verify it's deleted
```

### Test Case 2: Multiple Watchlists

```
1. Create "Tech Stocks"
2. Add AAPL, MSFT
3. Create "Energy Stocks"
4. Add XOM, CVX
5. Switch between watchlists
6. Verify stocks are separate
```

### Test Case 3: Cache Validation

```
1. Add AAPL to watchlist
2. Analyze (note time)
3. Immediately re-analyze
4. Should be instant (cached)
5. Wait 5+ minutes
6. Re-analyze
7. Should fetch fresh data
```

### Test Case 4: Error Handling

```
1. Try adding invalid symbol "XXXX"
2. Should show error
3. Try adding empty symbol
4. Should show error
5. Try adding duplicate
6. Should show warning
```

---

## 🔒 Security Checklist

Before production:

- [ ] Enable user authentication
- [ ] Validate user_id on all operations
- [ ] Set up Row Level Security in Supabase
- [ ] Use environment variables for API keys
- [ ] Implement rate limiting
- [ ] Add input sanitization
- [ ] Enable HTTPS only
- [ ] Set up monitoring/logging

---

## 📈 Performance Benchmarks

### Expected Performance

| Operation | Target Time | Notes |
|-----------|-------------|-------|
| Create watchlist | <0.1s | Session state |
| Add stock | <0.2s | With validation |
| Analyze 1 stock | 1-2s | First time |
| Analyze 1 stock (cached) | <0.1s | From cache |
| Analyze 10 stocks | 10-20s | Sequential |
| Load watchlist | <0.1s | Session state |
| Delete watchlist | <0.1s | Session state |

### Database Performance (After Migration)

| Operation | Target Time | Notes |
|-----------|-------------|-------|
| Create watchlist | <0.5s | Database write |
| Load watchlist | <0.3s | Database read |
| Add stock | <0.4s | Database write |
| Bulk load | <1s | Up to 50 stocks |

---

## 🎯 Week 2 Goals

According to your 14-Week Execution Plan:

### Days 1-2: Integration & Testing
- [x] Build watchlists page ✅
- [ ] Deploy to Streamlit Cloud
- [ ] Test with 3-5 beta users
- [ ] Collect feedback

### Days 3-4: Database Migration
- [ ] Set up Supabase project
- [ ] Run database migrations
- [ ] Switch from session state to database
- [ ] Test persistence

### Days 5-6: Polish & Optimize
- [ ] Add sorting/filtering
- [ ] Implement async analysis
- [ ] Add export to CSV
- [ ] Performance optimization

### Day 7: Documentation & Handoff
- [x] Complete documentation ✅
- [ ] Create video tutorial
- [ ] Prepare for Week 3 (Alerts)

---

## 📞 Next Steps

### Immediate (Today)
1. ✅ Copy `3_Watchlists.py` to your project
2. Test locally with a few stocks
3. Verify integration with existing pages
4. Create a few test watchlists

### This Week (Week 2)
1. Deploy to Streamlit Cloud
2. Set up Supabase account
3. Migrate to database storage
4. Beta test with friends/family

### Next Week (Week 3)
1. Build Alerts system
2. Integrate alerts with watchlists
3. Add email notifications
4. Continue polish and optimization

---

## 🎉 Success Criteria

You'll know the feature is working when:

- ✅ You can create multiple watchlists
- ✅ You can add stocks and see them in the list
- ✅ "Analyze All" shows TR status for all stocks
- ✅ Cache works (instant re-analysis)
- ✅ UI is responsive and looks professional
- ✅ No errors or crashes

---

## 📚 Additional Resources

### Documentation
- `WATCHLISTS_README.md` - Complete feature documentation
- `watchlist_database.py` - Database schema and functions
- This file - Integration guide

### Reference Code
- `1_Stocks_Analysis.py` - Pattern for page structure
- `6_Indicator_Chart.py` - Pattern for analysis
- `cached_data.py` - Data fetching pattern

### External Resources
- [Streamlit Docs](https://docs.streamlit.io)
- [Supabase Docs](https://supabase.com/docs)
- [Plotly Docs](https://plotly.com/python/)

---

## 💬 Need Help?

If you encounter issues:

1. Check the Troubleshooting section above
2. Verify all files are in the correct location
3. Check the console for error messages
4. Review the testing scenarios
5. Ask me in our next chat! 😊

---

**Your watchlists feature is ready to go!** 🚀

Copy the file, test it, and start building your stock watchlists!

---

**Document Version:** 1.0
**Created:** November 11, 2025
**For:** MJ Software - Week 2
