"""
Watchlists Page - Manage Stock Watchlists
Create, edit, and analyze multiple watchlists with TR status overview
"""

import streamlit as st
import sys
import os
import pandas as pd
from datetime import datetime

# Add src directory to path
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
src_path = os.path.join(project_root, 'src')

if src_path not in sys.path:
    sys.path.insert(0, src_path)

from stock_lookup import get_stock_info
from cached_data import get_shared_stock_data

st.set_page_config(
    page_title="Watchlists - MJ Software",
    page_icon="📋",
    layout="wide"
)

# CSS for styling
st.markdown("""
<style>
    /* Button styling */
    .stButton > button {
        height: 38px !important;
        padding: 6px 16px !important;
        font-size: 14px !important;
    }
    
    /* Watchlist card styling */
    .watchlist-card {
        background-color: #f0f2f6;
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 10px;
        border-left: 4px solid #1f77b4;
    }
    
    .watchlist-header {
        font-size: 18px;
        font-weight: bold;
        margin-bottom: 8px;
        color: #1f77b4;
    }
    
    .watchlist-info {
        font-size: 14px;
        color: #666;
        margin-bottom: 5px;
    }
    
    /* Stock table styling */
    .stock-row {
        padding: 10px;
        margin: 5px 0;
        background-color: #ffffff;
        border-radius: 5px;
        border: 1px solid #e0e0e0;
    }
    
    /* TR Status badges */
    .tr-strong-buy {
        background-color: #00CC00;
        color: white;
        padding: 4px 12px;
        border-radius: 4px;
        font-weight: bold;
        font-size: 12px;
    }
    
    .tr-buy {
        background-color: #66CC66;
        color: white;
        padding: 4px 12px;
        border-radius: 4px;
        font-weight: bold;
        font-size: 12px;
    }
    
    .tr-neutral {
        background-color: #FFCC00;
        color: black;
        padding: 4px 12px;
        border-radius: 4px;
        font-weight: bold;
        font-size: 12px;
    }
    
    .tr-sell {
        background-color: #FF6666;
        color: white;
        padding: 4px 12px;
        border-radius: 4px;
        font-weight: bold;
        font-size: 12px;
    }
    
    .tr-strong-sell {
        background-color: #CC0000;
        color: white;
        padding: 4px 12px;
        border-radius: 4px;
        font-weight: bold;
        font-size: 12px;
    }
    
    .tr-loading {
        background-color: #999999;
        color: white;
        padding: 4px 12px;
        border-radius: 4px;
        font-weight: bold;
        font-size: 12px;
    }
</style>
""", unsafe_allow_html=True)

# ============================================================================
# SESSION STATE INITIALIZATION
# ============================================================================

def initialize_session_state():
    """Initialize session state for watchlists"""
    if 'watchlists' not in st.session_state:
        # Structure: {watchlist_id: {'name': str, 'created_at': datetime, 'stocks': []}}
        st.session_state.watchlists = {}
    
    if 'next_watchlist_id' not in st.session_state:
        st.session_state.next_watchlist_id = 1
    
    if 'active_watchlist' not in st.session_state:
        st.session_state.active_watchlist = None
    
    if 'stock_tr_cache' not in st.session_state:
        # Cache TR results to avoid re-fetching: {symbol: {'tr_status': str, 'current_price': float, ...}}
        st.session_state.stock_tr_cache = {}

# ============================================================================
# WATCHLIST MANAGEMENT FUNCTIONS
# ============================================================================

def create_watchlist(name):
    """Create a new watchlist"""
    watchlist_id = st.session_state.next_watchlist_id
    st.session_state.watchlists[watchlist_id] = {
        'name': name,
        'created_at': datetime.now(),
        'stocks': []
    }
    st.session_state.next_watchlist_id += 1
    st.session_state.active_watchlist = watchlist_id
    return watchlist_id

def delete_watchlist(watchlist_id):
    """Delete a watchlist"""
    if watchlist_id in st.session_state.watchlists:
        del st.session_state.watchlists[watchlist_id]
        if st.session_state.active_watchlist == watchlist_id:
            st.session_state.active_watchlist = None

def rename_watchlist(watchlist_id, new_name):
    """Rename a watchlist"""
    if watchlist_id in st.session_state.watchlists:
        st.session_state.watchlists[watchlist_id]['name'] = new_name

def add_stock_to_watchlist(watchlist_id, symbol):
    """Add a stock to a watchlist"""
    if watchlist_id in st.session_state.watchlists:
        stocks = st.session_state.watchlists[watchlist_id]['stocks']
        if symbol not in stocks:
            stocks.append(symbol)
            return True
    return False

def remove_stock_from_watchlist(watchlist_id, symbol):
    """Remove a stock from a watchlist"""
    if watchlist_id in st.session_state.watchlists:
        stocks = st.session_state.watchlists[watchlist_id]['stocks']
        if symbol in stocks:
            stocks.remove(symbol)
            return True
    return False

def get_watchlist_summary(watchlist_id):
    """Get summary stats for a watchlist"""
    if watchlist_id not in st.session_state.watchlists:
        return None
    
    watchlist = st.session_state.watchlists[watchlist_id]
    stock_count = len(watchlist['stocks'])
    
    return {
        'name': watchlist['name'],
        'stock_count': stock_count,
        'created_at': watchlist['created_at']
    }

# ============================================================================
# TR ANALYSIS FUNCTIONS
# ============================================================================

def get_tr_status_badge(tr_status):
    """Get HTML badge for TR status"""
    if not tr_status:
        return '<span class="tr-loading">Loading...</span>'
    
    status_map = {
        'Strong Buy': 'tr-strong-buy',
        'Buy': 'tr-buy',
        'Neutral': 'tr-neutral',
        'Sell': 'tr-sell',
        'Strong Sell': 'tr-strong-sell'
    }
    
    css_class = status_map.get(tr_status, 'tr-loading')
    return f'<span class="{css_class}">{tr_status}</span>'

def analyze_stock_quick(symbol):
    """Quick TR analysis for a single stock (cached)"""
    # Check cache first
    if symbol in st.session_state.stock_tr_cache:
        cached_time = st.session_state.stock_tr_cache[symbol].get('timestamp', datetime.min)
        # Cache valid for 5 minutes
        if (datetime.now() - cached_time).seconds < 300:
            return st.session_state.stock_tr_cache[symbol]
    
    try:
        # Get stock data with TR analysis
        df = get_shared_stock_data(
            ticker=symbol,
            duration_days=365,
            timeframe='daily',
            api_source='yahoo',
            include_tr=True  # Need TR for status
        )
        
        if df is None or df.empty:
            return None
        
        # Get latest data
        latest = df.iloc[-1]
        
        # Determine TR status from TR value
        tr_value = latest.get('TR', None)
        if tr_value is None or pd.isna(tr_value):
            tr_status = "N/A"
        else:
            if tr_value >= 2:
                tr_status = "Strong Buy"
            elif tr_value >= 1:
                tr_status = "Buy"
            elif tr_value >= -1:
                tr_status = "Neutral"
            elif tr_value >= -2:
                tr_status = "Sell"
            else:
                tr_status = "Strong Sell"
        
        # Calculate price change
        if len(df) > 1:
            prev_close = df.iloc[-2]['Close']
            price_change = latest['Close'] - prev_close
            price_change_pct = (price_change / prev_close) * 100
        else:
            price_change = 0
            price_change_pct = 0
        
        result = {
            'symbol': symbol,
            'current_price': latest['Close'],
            'tr_status': tr_status,
            'tr_value': tr_value,
            'price_change': price_change,
            'price_change_pct': price_change_pct,
            'timestamp': datetime.now()
        }
        
        # Cache result
        st.session_state.stock_tr_cache[symbol] = result
        
        return result
    
    except Exception as e:
        st.warning(f"Error analyzing {symbol}: {str(e)}")
        return None

# ============================================================================
# UI COMPONENTS
# ============================================================================

def show_watchlist_selector():
    """Show watchlist selector sidebar"""
    st.sidebar.header("📋 Your Watchlists")
    
    watchlists = st.session_state.watchlists
    
    if not watchlists:
        st.sidebar.info("No watchlists yet. Create one to get started!")
    else:
        for wl_id, wl_data in watchlists.items():
            summary = get_watchlist_summary(wl_id)
            if summary:
                col1, col2 = st.sidebar.columns([3, 1])
                with col1:
                    if st.button(
                        f"📊 {summary['name']} ({summary['stock_count']})",
                        key=f"select_wl_{wl_id}",
                        use_container_width=True
                    ):
                        st.session_state.active_watchlist = wl_id
                        st.rerun()
                
                with col2:
                    if st.button("🗑️", key=f"delete_wl_{wl_id}"):
                        delete_watchlist(wl_id)
                        st.rerun()
    
    st.sidebar.divider()

def show_create_watchlist_form():
    """Show form to create a new watchlist"""
    st.sidebar.subheader("➕ Create New Watchlist")
    
    with st.sidebar.form("create_watchlist_form"):
        new_name = st.text_input("Watchlist Name", placeholder="e.g., Tech Stocks")
        submit = st.form_submit_button("Create Watchlist")
        
        if submit and new_name:
            wl_id = create_watchlist(new_name.strip())
            st.success(f"✅ Created watchlist: {new_name}")
            st.rerun()
        elif submit:
            st.error("Please enter a name for the watchlist")

def show_add_stock_form(watchlist_id):
    """Show form to add stocks to current watchlist"""
    st.subheader("➕ Add Stock to Watchlist")
    
    col1, col2 = st.columns([3, 1])
    
    with col1:
        # Stock symbol input
        new_symbol = st.text_input(
            "Enter Stock Symbol",
            placeholder="e.g., AAPL, MSFT, GOOGL",
            key=f"add_stock_input_{watchlist_id}"
        ).upper()
    
    with col2:
        st.write("")  # Spacing
        st.write("")  # Spacing
        add_button = st.button("Add Stock", key=f"add_stock_btn_{watchlist_id}")
    
    if add_button and new_symbol:
        # Validate stock symbol
        stock_info = get_stock_info(new_symbol)
        
        if stock_info:
            # Add to watchlist
            success = add_stock_to_watchlist(watchlist_id, new_symbol)
            if success:
                st.success(f"✅ Added {new_symbol} - {stock_info.get('name', '')} to watchlist")
                st.rerun()
            else:
                st.warning(f"⚠️ {new_symbol} is already in this watchlist")
        else:
            st.error(f"❌ Invalid symbol: {new_symbol}")
    
    st.divider()

def show_watchlist_stocks(watchlist_id):
    """Display all stocks in the watchlist with analysis"""
    watchlist = st.session_state.watchlists.get(watchlist_id)
    
    if not watchlist:
        st.error("Watchlist not found")
        return
    
    stocks = watchlist['stocks']
    
    if not stocks:
        st.info("📊 This watchlist is empty. Add some stocks to get started!")
        return
    
    st.subheader(f"📊 Stocks in {watchlist['name']} ({len(stocks)})")
    
    # Analyze All button
    col1, col2, col3 = st.columns([1, 1, 3])
    with col1:
        analyze_all = st.button("🔄 Analyze All Stocks", key=f"analyze_all_{watchlist_id}")
    with col2:
        clear_cache = st.button("🗑️ Clear Cache", key=f"clear_cache_{watchlist_id}")
    
    if clear_cache:
        st.session_state.stock_tr_cache = {}
        st.success("✅ Cache cleared")
        st.rerun()
    
    # Show stocks in a table
    stock_data = []
    
    with st.spinner("Analyzing stocks..."):
        for symbol in stocks:
            if analyze_all or symbol in st.session_state.stock_tr_cache:
                analysis = analyze_stock_quick(symbol)
                if analysis:
                    stock_data.append(analysis)
            else:
                # Show placeholder
                stock_data.append({
                    'symbol': symbol,
                    'current_price': None,
                    'tr_status': None,
                    'price_change_pct': None
                })
    
    # Display stocks
    for idx, stock in enumerate(stock_data):
        col1, col2, col3, col4, col5, col6 = st.columns([2, 2, 2, 2, 2, 1])
        
        with col1:
            st.write(f"**{stock['symbol']}**")
        
        with col2:
            if stock['current_price']:
                st.write(f"${stock['current_price']:.2f}")
            else:
                st.write("—")
        
        with col3:
            if stock['price_change_pct'] is not None:
                color = "green" if stock['price_change_pct'] >= 0 else "red"
                sign = "+" if stock['price_change_pct'] >= 0 else ""
                st.markdown(f"<span style='color:{color}'>{sign}{stock['price_change_pct']:.2f}%</span>", 
                          unsafe_allow_html=True)
            else:
                st.write("—")
        
        with col4:
            if stock['tr_status']:
                st.markdown(get_tr_status_badge(stock['tr_status']), unsafe_allow_html=True)
            else:
                st.markdown(get_tr_status_badge(None), unsafe_allow_html=True)
        
        with col5:
            if st.button("📊 Analyze", key=f"analyze_{watchlist_id}_{idx}_{stock['symbol']}"):
                # Navigate to Stock Analysis page (would need proper routing)
                st.info(f"Navigate to analysis for {stock['symbol']}")
        
        with col6:
            if st.button("❌", key=f"remove_{watchlist_id}_{idx}_{stock['symbol']}"):
                remove_stock_from_watchlist(watchlist_id, stock['symbol'])
                st.rerun()
        
        st.divider()
    
    # Summary statistics
    st.divider()
    st.subheader("📈 Watchlist Summary")
    
    # Calculate summary stats
    analyzed_stocks = [s for s in stock_data if s['tr_status']]
    
    if analyzed_stocks:
        strong_buy = sum(1 for s in analyzed_stocks if s['tr_status'] == 'Strong Buy')
        buy = sum(1 for s in analyzed_stocks if s['tr_status'] == 'Buy')
        neutral = sum(1 for s in analyzed_stocks if s['tr_status'] == 'Neutral')
        sell = sum(1 for s in analyzed_stocks if s['tr_status'] == 'Sell')
        strong_sell = sum(1 for s in analyzed_stocks if s['tr_status'] == 'Strong Sell')
        
        col1, col2, col3, col4, col5 = st.columns(5)
        
        with col1:
            st.metric("Strong Buy", strong_buy)
        with col2:
            st.metric("Buy", buy)
        with col3:
            st.metric("Neutral", neutral)
        with col4:
            st.metric("Sell", sell)
        with col5:
            st.metric("Strong Sell", strong_sell)
    else:
        st.info("Click 'Analyze All Stocks' to see TR status for all stocks in this watchlist")

# ============================================================================
# MAIN APP
# ============================================================================

def main():
    """Main application"""
    
    # Check if user is logged in (placeholder)
    if 'logged_in' not in st.session_state:
        st.session_state.logged_in = True  # Auto-login for development
    
    if not st.session_state.logged_in:
        st.warning("⚠️ Please log in to access Watchlists")
        return
    
    # Initialize session state
    initialize_session_state()
    
    # Show title
    st.title("📋 Watchlists")
    st.markdown("*Create and manage multiple stock watchlists with TR indicator analysis*")
    st.divider()
    
    # Sidebar
    show_watchlist_selector()
    show_create_watchlist_form()
    
    # Main content
    if st.session_state.active_watchlist is None:
        # No watchlist selected
        st.info("👈 Select a watchlist from the sidebar or create a new one to get started")
        
        # Show quick start guide
        st.subheader("🚀 Quick Start Guide")
        st.markdown("""
        **Getting Started with Watchlists:**
        
        1. **Create a Watchlist**: Click "Create New Watchlist" in the sidebar
        2. **Add Stocks**: Enter stock symbols to add them to your watchlist
        3. **Analyze Stocks**: Click "Analyze All Stocks" to see TR status for all stocks
        4. **Monitor Performance**: Track price changes and TR signals
        
        **Watchlist Features:**
        - ✅ Create unlimited watchlists
        - ✅ Add unlimited stocks to each watchlist
        - ✅ Quick TR analysis for all stocks
        - ✅ Price change tracking
        - ✅ One-click navigation to full analysis
        """)
        
    else:
        # Show selected watchlist
        watchlist = st.session_state.watchlists.get(st.session_state.active_watchlist)
        
        if watchlist:
            # Watchlist header
            col1, col2 = st.columns([4, 1])
            with col1:
                st.header(f"📊 {watchlist['name']}")
                st.caption(f"Created: {watchlist['created_at'].strftime('%B %d, %Y')}")
            
            with col2:
                # Rename watchlist
                with st.popover("⚙️ Settings"):
                    new_name = st.text_input("Rename Watchlist", value=watchlist['name'])
                    if st.button("Save Name"):
                        rename_watchlist(st.session_state.active_watchlist, new_name)
                        st.success("✅ Renamed!")
                        st.rerun()
            
            st.divider()
            
            # Add stock form
            show_add_stock_form(st.session_state.active_watchlist)
            
            # Show stocks
            show_watchlist_stocks(st.session_state.active_watchlist)
        else:
            st.error("Watchlist not found")

if __name__ == "__main__":
    main()
