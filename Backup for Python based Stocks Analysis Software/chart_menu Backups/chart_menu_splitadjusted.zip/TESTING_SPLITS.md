# 🧪 TESTING SPLIT ADJUSTMENT - Quick Guide

## ✅ **How to Verify It Works:**

### **Test 1: NVDA (Known 10-for-1 Split)**

```bash
python chart_menu_v2_LOCAL.py

Symbol: NVDA
Timeframe: Daily  
Duration: 1 Year
```

**Expected Output:**
```
⚠️  CRITICAL: Detected 1 unadjusted split(s) in NVDA!
   • 2024-06-07: ~10.0-for-1 split
     $1200.00 → $120.00 (-90.0% drop)

🔧 Adjusting data for 1 split(s)...
   • Adjusting pre-2024-06-07 data by factor of 10.00
   ✅ Split adjustment complete!

   ✅ Verification: All splits corrected! Data is now continuous.
```

**Chart Should Show:**
- ✅ Smooth line, no vertical gaps
- ✅ Price around $100-140 throughout
- ✅ EMAs follow price smoothly

---

### **Test 2: GOOGL (20-for-1 Split, July 2022)**

```bash
Symbol: GOOGL
Duration: 3 Years
```

**Should detect and adjust the 2022 split**

---

### **Test 3: AAPL (No Recent Splits)**

```bash
Symbol: AAPL
Duration: 1 Year
```

**Expected Output:**
```
(No split warnings)
✅ Data created: 365 days
✅ EMAs calculated: 50 Day EMA and 200 Day EMA
```

**Chart Should Show:**
- Normal processing, no adjustments needed

---

## 🔍 **Visual Verification:**

### **✅ GOOD Chart (Adjusted):**
```
Price
  |     /\
  |    /  \    /\
  | /\/    \  /  \
  |/        \/    \___
  +--------------------> Time
  
Smooth, continuous line
```

### **❌ BAD Chart (Unadjusted):**
```
Price
  |          |
  |       ___|___
  |      /   |
  |  /\/     |
  |/         90% drop!
  +--------------------> Time
  
Sudden vertical gap
```

---

## 📊 **What to Check:**

1. **Console Output**
   - Splits detected? ✅
   - Adjustment applied? ✅  
   - Verification passed? ✅

2. **Chart Visual**
   - Smooth line? ✅
   - No gaps? ✅
   - EMAs track price? ✅

3. **Price Range**
   - NVDA: $100-150 range ✅
   - Not: $120 to $1,200 ❌

---

## 🎯 **Quick Test Matrix:**

| Symbol | Duration | Expected |
|--------|----------|----------|
| NVDA | 1 Year | Split detected & adjusted |
| GOOGL | 3 Years | Split detected & adjusted |
| TSLA | 3 Years | Split detected & adjusted |
| AAPL | 1 Year | No splits, normal |
| MSFT | 1 Year | No splits, normal |

---

## 🐛 **If It Doesn't Work:**

### **Problem: No splits detected but chart has gap**

**Cause:** Threshold too high

**Fix:** Lower threshold in code:
```python
splits = detect_stock_splits(df, threshold=0.15)  # Was 0.20
```

### **Problem: False positive (crash detected as split)**

**Cause:** Threshold too low

**Fix:** Increase threshold:
```python
splits = detect_stock_splits(df, threshold=0.30)  # Was 0.20
```

---

## ✅ **Success Criteria:**

You know it's working when:
1. ✅ Console shows split detection for NVDA
2. ✅ Console shows adjustment being applied
3. ✅ Verification passes
4. ✅ Chart is smooth with no gaps
5. ✅ AAPL shows no splits (correct)

---

**Test NVDA first - it's the best example!** 🎯
