# 🎯 QUICK REFERENCE - Version 3.0

## ⚡ **Quick Commands**

| Command | Action |
|---------|--------|
| **Q** or **QUIT** or **EXIT** | Quit symbol input → Back to menu |
| **0** (at main menu) | Exit program completely |
| **y** (after error) | Try again with new symbol |
| **n** (after error) | Back to main menu |
| **y** (after success) | Create another chart |
| **n** (after success) | Back to main menu |

---

## 📊 **3-Step Process**

```
Step 0: Enter Symbol (or Q to quit)
Step 1: Select Timeframe (1=Daily, 2=Weekly)
Step 2: Select Duration (1-5)
```

---

## 🛡️ **Error Handling**

### Invalid Format
```
Enter: AAPL123
→ Loops back to symbol input
```

### Invalid Symbol
```
Enter: BADTICKER
→ Goes through flow
→ Error at fetch
→ "Try again? (y/n)"
→ y = new symbol
→ n = main menu
```

### Want to Quit
```
Enter: Q
→ Back to main menu immediately
```

---

## ✅ **Valid Symbols**

Format: 1-5 letters, no numbers/symbols

- ✅ AAPL
- ✅ MSFT
- ✅ GOOGL
- ✅ TSLA
- ✅ A
- ❌ AAPL123
- ❌ $AAPL
- ❌ TOOLONG

---

## 🔄 **Flow Summary**

```
Main Menu
   ↓
Enter Symbol (can quit with Q)
   ↓
Select Timeframe
   ↓
Select Duration
   ↓
Fetch Data
   ↓
   ├─ Success → Show chart → Another? (y/n)
   └─ Error → Retry? (y/n)
        ↓
   Back to Main Menu
```

---

## 💡 **Pro Tips**

1. **Type 'Q' anytime** during symbol input to quit
2. **Retry** automatically loops on format errors
3. **Retry option** appears after API errors
4. **Case insensitive** - q, Q, quit all work
5. **Can exit** from multiple points

---

## 🎨 **Example Session**

```
Menu → 1
Symbol → Q (quit)
Back to Menu

Menu → 1
Symbol → AAPL123 (invalid format)
Symbol → AAPL (valid)
Timeframe → 1
Duration → 3
→ Success! Chart created
Another? → y

Symbol → BADTICKER (valid format)
Timeframe → 1
Duration → 3
→ Error! Symbol not found
Retry? → y

Symbol → MSFT (valid)
Timeframe → 2
Duration → 4
→ Success! Chart created
Another? → n
Back to Menu

Menu → 0
Exit program
```

---

**Version 3.0 - Full control, no dead ends!** ✅
